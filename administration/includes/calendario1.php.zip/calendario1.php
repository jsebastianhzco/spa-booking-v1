<?php



session_start();

header('Access-Control-Allow-Origin: *');

header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");

header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

header("Allow: GET, POST, OPTIONS, PUT, DELETE");



//require_once '../config/conexion.php';



include "../config/app.php";

// Create connection



$conn = mysqli_connect($servername, $username, $password, $db);







// Check connection



if (!$conn) {

   



    die("Connection failed: " . mysqli_connect_error());



}







$agenda = "SELECT re.start , re.title , re.end , re.url, re.backgroundColor, re.description, ser.nombre_servicio , ser.id_servicio , cli.id_cliente , cli.nombre_cliente , cli.apellido_cliente



FROM reservas as re 



INNER JOIN servicios as ser ON ser.id_servicio = re.title 



INNER JOIN clientes as cli ON cli.id_cliente = re.id_cliente";







$result = mysqli_query($conn, $agenda);



$response = [];







if (mysqli_num_rows($result) > 0) {



    while($row = mysqli_fetch_assoc($result)) {



        $response[] = [

            'start' => $row['start'],

            'end' => $row['end'],

            'title' => $row['title'],

            'nombre_servicio' => $row['nombre_servicio'],

            'backgroundColor' => $row['backgroundColor'],

            'url' => $row['url'],

            'description' => $row['description'],

            'id_cliente' => $row['id_cliente'],

            'nombre_cliente' => $row['nombre_cliente'],

            'apellido_cliente' =>$row['apellido_cliente'],

        ];



        }



     }



     



;



      if ($_SERVER['REQUEST_METHOD'] == "POST" || $_SERVER['REQUEST_METHOD'] == "GET") { echo json_encode($response); }   











?>











<?php 



                              



                              



                              if(empty($_SESSION['usuario'])){







                              ?>



                              <script>



                                 window.location.href="login.php";



                              </script>



                              <?php } ?> 